import Store from './stores/Store'

const store = new Store()

store.createItem('A')
console.log(store.toJS(), store)

window.store = store