import Item from './Item'
import Box from './Box'
import {
  move,
  deleteFromMap,
  deleteFromArray
} from './common'

class Store {
  items = {}
  boxes = {}
  boxIds = []

  constructor() {
    // init firstBox
    const firstBox = new Box(this, true)
    this.firstBox = firstBox
    this.boxIds[0] = firstBox.id
    this.boxes[firstBox.id] = firstBox
  }

  createItem(name) {
    const item = new Item(this, name)
    this.items[item.id] = item
    this.firstBox.addItem(item.id)
  }

  deleteItem(itemId) {
    Object.values(this.boxes).forEach(box => box.removeItem(itemId))
    this.items = deleteFromMap(itemId, this.items)
  }

  createBox() {
    const box = new Box(this)
    this.boxes[box.id] = box
    this.boxIds.push(box.id)
  }

  deleteBox(boxId) {
    this.boxIds = deleteFromArray(boxId, this.boxIds)
    this.boxes = deleteFromMap(boxId, this.boxes)
  }

  get boxList() {
    return this.boxIds.map(boxId => this.boxes[boxId])
  }

  moveBox(fromIndex, toIndex) {
    this.boxIds = move(this.boxIds, fromIndex, toIndex)
  }

  moveItemBetweenBox(itemId, fromBoxId, toBoxId) {
    if (fromBoxId) {
      const boxA = this.boxes[fromBoxId]
      boxA.removeItem(itemId)
    } else {
      throw new Error('formBoxId not supply')
    }

    if (toBoxId) {
      const boxB = this.boxes[toBoxId]
      boxB.addItem(itemId)
    }
  }

  toJS() {
    return {
      items: Object.values(this.items).map(item => item.toJS()),
      boxes: this.boxList.map(box => box.toJS())
    }
  }
}

export default Store